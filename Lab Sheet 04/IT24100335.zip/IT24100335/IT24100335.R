# 1. Import the dataset and store it as 'branch_data'
branch_data <- read.csv("C://Users//it24100335//Desktop//IT24100335//Exercise.txt", sep = ",")

# 2. Identify variable types and scales
str(branch_data)
# All variables (Sales_X1, Advertising_X2, Years_X3) are numeric and use the Ratio scale.

# 3. Obtain boxplot for Sales and interpret the shape
boxplot(branch_data$Sales_X1,
        main = "Boxplot of Sales",
        xlab = "Sales",
        horizontal = TRUE,
        col = "lightblue",
        border = "darkblue")

# 4. Calculate the five-number summary and IQR for Advertising
summary(branch_data$Advertising_X2)
iqr_advertising <- IQR(branch_data$Advertising_X2)
print(paste("IQR for Advertising:", iqr_advertising))

# 5. Function to find outliers in a numeric vector
get_outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3 - q1
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 + 1.5 * iqr
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

# Check for outliers in Years
years_outliers <- get_outliers(branch_data$Years_X3)
print("Outliers in Years:")
print(years_outliers)
